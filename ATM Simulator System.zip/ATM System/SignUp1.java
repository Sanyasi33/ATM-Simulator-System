import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import java.sql.*;
import java.util.regex.Pattern;
public class SignUp1 extends JFrame implements ActionListener
{
	Welcome wc1;
	int RandomNumber;
	JLabel li,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	JRadioButton rb1,rb2;
	ButtonGroup bg;
	JButton b1;
	
	Connection con;
	Statement st;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams"; 	// (AMS for GUI DB & system for CUI DB)
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	// Mail Validation
	String emailRegex="^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@"+"(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	Pattern ptrn1=Pattern.compile(emailRegex);
	// PinCode Validation
	String pinRegex="\\d{6}";
	Pattern ptrn2=Pattern.compile(pinRegex);
	// Age Validation
	String ageRegex="[0-9]{2}";
	Pattern ptrn3=Pattern.compile(ageRegex);
	
	public SignUp1(Welcome wc2)
	{
		wc1=wc2;
		setTitle("SignUp1");
		
		// Background Image
		ImageIcon ic=new ImageIcon("bg2.jpg");
		Image ii=ic.getImage().getScaledInstance(650,750,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,650,750);
		add(li);
		
		// Label for Bank_logo
		ImageIcon ic1=new ImageIcon("logo.jpg");
		Image i=ic1.getImage().getScaledInstance(80,80,Image.SCALE_DEFAULT);
		ImageIcon ic2=new ImageIcon(i);
		l1=new JLabel(ic2);
		l1.setBounds(50,25,80,80);
		li.add(l1);
		
		// Random number
		Random rnd=new Random();
		RandomNumber=rnd.nextInt(8999)+1000;
		
		// Label for Application_Form_no: xxxx
		l2=new JLabel("Application Form No: "+RandomNumber);
		l2.setBounds(150,5,400,80);
		l2.setFont(new Font("Osward",Font.BOLD,30));
		l2.setForeground(Color.GREEN);
		li.add(l2);
		
		// Label for Page1: Personal Details
		l3=new JLabel("Page1: Personal Details");
		l3.setBounds(200,45,400,80);
		l3.setFont(new Font("Osward",Font.BOLD,25));
		l3.setForeground(Color.GREEN);
		li.add(l3);
		
		// Font for all labels
		Font f2=new Font("Arial",Font.PLAIN,25);
		
		// Font for all TextFileds
		Font f3=new Font("Arial",Font.PLAIN,20);
		
		// Label for Name:
		l4=new JLabel("Name:");
		l4.setBounds(50,150,100,35);
		l4.setFont(f2);
		l4.setForeground(Color.CYAN);
		li.add(l4);
		
		// Text Field for Name
		t1=new JTextField();
		t1.setBounds(250,150,300,35);
		t1.setFont(f3);
		li.add(t1);
		
		// Label for Fathers Name:
		l5=new JLabel("Father's Name:");
		l5.setBounds(50,200,200,35);
		l5.setFont(f2);
		l5.setForeground(Color.CYAN);
		li.add(l5);
		
		// Text Field for Father's Name
		t2=new JTextField();
		t2.setBounds(250,200,300,35);
		t2.setFont(f3);
		li.add(t2);
		
		// Label for Age:
		l6=new JLabel("Age:");
		l6.setBounds(50,250,200,35);
		l6.setFont(f2);
		l6.setForeground(Color.CYAN);
		li.add(l6);
		
		// Text Field for Age
		t8=new JTextField();
		t8.setBounds(250,250,300,35);
		t8.setFont(f3);
		li.add(t8);
		
		// Label for Gender:
		l7=new JLabel("Gender:");
		l7.setBounds(50,300,200,35);
		l7.setFont(f2);
		l7.setForeground(Color.CYAN);
		li.add(l7);
		
		// JRadioButton for Male
		rb1=new JRadioButton("Male");
		rb1.setBounds(250,300,135,35);
		rb1.setFont(f2);
		rb1.setSelected(true);
		li.add(rb1);
		
		// JRadioButton for Female
		rb2=new JRadioButton("Female");
		rb2.setBounds(410,300,140,35);
		rb2.setFont(f2);
		li.add(rb2);
		
		// ButtonGroup
		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		
		// Label for Email Address:
		l8=new JLabel("Email Address:");
		l8.setBounds(50,350,200,35);
		l8.setFont(f2);
		l8.setForeground(Color.CYAN);
		li.add(l8);
		
		// Text Field for Email Address
		t3=new JTextField();
		t3.setBounds(250,350,300,35);
		t3.setFont(f3);
		li.add(t3);
		
		// Label for Address:
		l9=new JLabel("Address:");
		l9.setBounds(50,400,200,35);
		l9.setFont(f2);
		l9.setForeground(Color.CYAN);
		li.add(l9);
		
		// Text Field for Address
		t4=new JTextField();
		t4.setBounds(250,400,300,35);
		t4.setFont(f3);
		li.add(t4);
		
		// Label for City:
		l10=new JLabel("City:");
		l10.setBounds(50,450,200,35);
		l10.setFont(f2);
		l10.setForeground(Color.CYAN);
		li.add(l10);
		
		// Text Field for City
		t5=new JTextField();
		t5.setBounds(250,450,300,35);
		t5.setFont(f3);
		li.add(t5);
		
		// Label for Pin Code:
		l11=new JLabel("Pin Code:");
		l11.setBounds(50,500,200,35);
		l11.setFont(f2);
		l11.setForeground(Color.CYAN);
		li.add(l11);
		
		// Text Field for Pin Code
		t6=new JTextField();
		t6.setBounds(250,500,300,35);
		t6.setFont(f3);
		li.add(t6);
		
		// Label for State:
		l12=new JLabel("State:");
		l12.setBounds(50,550,200,35);
		l12.setFont(f2);
		l12.setForeground(Color.CYAN);
		li.add(l12);
		
		// Text Field for State
		t7=new JTextField();
		t7.setBounds(250,550,300,35);
		t7.setFont(f3);
		li.add(t7);
		
		// Button
		b1=new JButton("Next");
		b1.setBounds(420,620,100,40);
		b1.setFont(new Font("Serif",Font.PLAIN,25));
		b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.BLUE);
		b1.addActionListener(this);
		li.add(b1);
		
		
		setBounds(300,50,650,750);
		setBackground(Color.WHITE);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		int formno=RandomNumber;
		String name=t1.getText();
		String fname=t2.getText();
		String age=t8.getText();
		String gender=null;
		if(rb1.isSelected())
		{
			gender="Male";
		}
		else if(rb2.isSelected())
		{
			gender="Female";
		}
		String mail=t3.getText();
		String address=t4.getText();
		String city=t5.getText();
		String pin=t6.getText();
		String state=t7.getText();
		
		String sqlquery="insert into signup1 values("+formno+",'"+name+"','"+fname+"','"+age+"','"+gender+"','"+mail+"','"+address+"','"+city+"','"+pin+"','"+state+"')";
		
		try
		{
			if(name.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Name is required");
			}
			else if(fname.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Father name is required");
			}
			else if(age.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Age is required");
			}
			else if(!(ptrn3.matcher(age).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Valid Age");
			}
			else if(mail.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Mail is required");
			}
			else if(!(ptrn1.matcher(mail).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Valid MAIL");
			}
			else if(address.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Address is required");
			}
			else if(city.equals(""))
			{
				JOptionPane.showMessageDialog(null,"City is required");
			}
			else if(pin.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Pin is required");
			}
			else if(!(ptrn2.matcher(pin).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Valid PIN_CODE");
			}
			else if(state.equals(""))
			{
				JOptionPane.showMessageDialog(null,"State is required");
			}
			else
			{
				Class.forName(clsname);
				con=DriverManager.getConnection(url,usr,pswd);
				st=con.createStatement();
				st.executeUpdate(sqlquery);
				JOptionPane.showMessageDialog(null,"Data Saved Successfully");
				setVisible(false);
				SignUp2 s2=new SignUp2(formno,this);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}