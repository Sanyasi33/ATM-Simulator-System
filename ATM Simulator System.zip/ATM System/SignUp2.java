import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.regex.Pattern;
public class SignUp2 extends JFrame implements ActionListener
{
	SignUp1 su1;
	int formno;
	JLabel li,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
	JLabel pi;
	JComboBox cb1,cb2,cb3,cb4,cb5;
	JTextField t1,t2;
	JButton b1;
	
	// String for ComboBox
	String[] religion={"Hindu","Muslim","Christian","Other"};
	String[] category={"General","OBC","SEBC","SC","ST","Other"};
	String[] income={"null","<200000","<500000","<1000000",">1000000"};
	String[] qualification={"Non-Graduate","Graduate","Post-Graduate","Doctrate","Others"};
	String[] occupation={"Salaried","Self-Employeed","Business","Student","Retired","Other"};
	
	Connection con;
	Statement st;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	// PanCard Validation
	String panRegex="[A-Z]{5}[0-9]{4}[A-Z]{1}";
	Pattern ptrn1=Pattern.compile(panRegex);
	// AadharCard Validation
	String aadharRegex="[2-9]{1}[0-9]{11}";
	Pattern ptrn2=Pattern.compile(aadharRegex);
	
	public SignUp2(int formno,SignUp1 su2)
	{
		this.formno=formno;
		su1=su2;
		setTitle("SignUp2");
		
		// Background Image
		ImageIcon ic=new ImageIcon("bg3.jpg");
		Image ii=ic.getImage().getScaledInstance(650,650,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,650,650);
		add(li);
		
		// Label for Bank_logo
		ImageIcon ic1=new ImageIcon("logo.jpg");
		Image i=ic1.getImage().getScaledInstance(80,80,Image.SCALE_DEFAULT);
		ImageIcon ic2=new ImageIcon(i);
		l1=new JLabel(ic2);
		l1.setBounds(50,25,80,80);
		li.add(l1);
		
		// Label for Application_Form_no: xxxx
		l2=new JLabel("Application Form No: "+formno);
		l2.setBounds(150,5,400,80);
		l2.setFont(new Font("Osward",Font.BOLD,30));
		l2.setForeground(Color.GREEN);
		li.add(l2);
		
		// Label for Page2: Additional Details
		l3=new JLabel("Page2: Additional Details");
		l3.setBounds(200,45,400,80);
		l3.setFont(new Font("Osward",Font.BOLD,25));
		l3.setForeground(Color.GREEN);
		li.add(l3);
		
		// Font for all labels
		Font f2=new Font("Arial",Font.PLAIN,25);
		
		// Font for all TextFileds
		Font f3=new Font("Arial",Font.PLAIN,20);
		
		// Label for Religion:
		l4=new JLabel("Religion:");
		l4.setBounds(50,150,100,35);
		l4.setFont(f2);
		l4.setForeground(Color.CYAN);
		li.add(l4);
		
		// ComboBox for Religion
		cb1=new JComboBox(religion);
		cb1.setBounds(250,150,300,35);
		cb1.setFont(f3);
		li.add(cb1);
		
		// Label for Category:
		l5=new JLabel("Category:");
		l5.setBounds(50,200,200,35);
		l5.setFont(f2);
		l5.setForeground(Color.CYAN);
		li.add(l5);
		
		// ComboBox for Category
		cb2=new JComboBox(category);
		cb2.setBounds(250,200,300,35);
		cb2.setFont(f3);
		li.add(cb2);
		
		// Label for Income:
		l6=new JLabel("Income:");
		l6.setBounds(50,250,200,35);
		l6.setFont(f2);
		l6.setForeground(Color.CYAN);
		li.add(l6);
		
		// ComboBox for Income
		cb3=new JComboBox(income);
		cb3.setBounds(250,250,300,35);
		cb3.setFont(f3);
		li.add(cb3);
		
		// Label for Qualification:
		l7=new JLabel("Qualification:");
		l7.setBounds(50,300,200,35);
		l7.setFont(f2);
		l7.setForeground(Color.CYAN);
		li.add(l7);
		
		// ComboBox for Qualification
		cb4=new JComboBox(qualification);
		cb4.setBounds(250,300,300,35);
		cb4.setFont(f3);
		li.add(cb4);
		
		// Label for Occupation:
		l8=new JLabel("Occupation:");
		l8.setBounds(50,350,200,35);
		l8.setFont(f2);
		l8.setForeground(Color.CYAN);
		li.add(l8);
		
		// ComboBox for Occupation
		cb5=new JComboBox(occupation);
		cb5.setBounds(250,350,300,35);
		cb5.setFont(f3);
		li.add(cb5);
		
		// Label for Pan Number:
		l9=new JLabel("Pan Number:");
		l9.setBounds(50,395,200,35);
		l9.setFont(f2);
		l9.setForeground(Color.CYAN);
		li.add(l9);
		// Label for Pan Instruction
		pi=new JLabel("(in Capital Letter)");
		pi.setBounds(50,414,200,35);
		pi.setFont(new Font("Arial",Font.PLAIN,18));
		pi.setForeground(Color.ORANGE);
		li.add(pi);
		
		// Text Field for Pan Number
		t1=new JTextField();
		t1.setBounds(250,400,300,35);
		t1.setFont(f3);
		li.add(t1);
		
		// Label for Aadhar Number:
		l10=new JLabel("Aadhar Number:");
		l10.setBounds(50,450,200,35);
		l10.setFont(f2);
		l10.setForeground(Color.CYAN);
		li.add(l10);
		
		// Text Field for Aadhar Number
		t2=new JTextField();
		t2.setBounds(250,450,300,35);
		t2.setFont(f3);
		li.add(t2);
		
		// Button
		b1=new JButton("Next");
		b1.setBounds(420,530,130,40);
		b1.setFont(new Font("Serif",Font.PLAIN,25));
		b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.BLUE);
		li.add(b1);
		
		b1.addActionListener(this);
		
		setBounds(300,50,650,650);
		setBackground(Color.WHITE);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String Ritem=(String)cb1.getSelectedItem();
		String Citem=(String)cb2.getSelectedItem();
		String Iitem=(String)cb3.getSelectedItem();
		String Qitem=(String)cb4.getSelectedItem();
		String Oitem=(String)cb5.getSelectedItem();
		String Pan=t1.getText();
		String Aadhar=t2.getText();

		String sqlquery="insert into signup2 values("+formno+",'"+Ritem+"','"+Citem+"','"+Iitem+"','"+Qitem+"','"+Oitem+"','"+Pan+"','"+Aadhar+"')";
		
		try
		{
			if(Pan.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Pan Number is required");
			}
			else if(!(ptrn1.matcher(Pan).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Valid Pan Number");
			}
			else if(Aadhar.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Aadhar Number is required");
			}
			else if(!(ptrn2.matcher(Aadhar).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Valid Aadhar Number");
			}
			else
			{
				Class.forName(clsname);
				con=DriverManager.getConnection(url,usr,pswd);
				st=con.createStatement();
				st.executeUpdate(sqlquery);
				JOptionPane.showMessageDialog(null,"Data Saved Successfully");
				setVisible(false);
				SignUp3 s3=new SignUp3(formno,this);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}