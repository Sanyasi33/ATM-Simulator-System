import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.regex.Pattern;
import java.util.Random;
public class SignUp3 extends JFrame implements ActionListener
{
	SignUp2 sp1;
	int formno;
	int rndno;
	String crdno=null;
	int pinno;
	JLabel li,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JRadioButton rb1,rb2,rb3,rb4;
	ButtonGroup bg;
	JCheckBox cb1,cb2,cb3,cb4,cb5;
	JButton b1;
	
	Connection con;
	Statement st;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	public SignUp3(int formno,SignUp2 sp2)
	{
		this.formno=formno;
		sp1=sp2;
		setTitle("SignUp3");
		
		// Background Image
		ImageIcon ic=new ImageIcon("bg4.jpg");
		Image ii=ic.getImage().getScaledInstance(650,750,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,650,750);
		add(li);
		
		// Label for Bank_logo
		ImageIcon ic1=new ImageIcon("logo.jpg");
		Image i=ic1.getImage().getScaledInstance(80,80,Image.SCALE_DEFAULT);
		ImageIcon ic2=new ImageIcon(i);
		l1=new JLabel(ic2);
		l1.setBounds(50,25,80,80);
		li.add(l1);
		
		// Label for Application_Form_no: xxxx
		l2=new JLabel("Application Form No: "+formno);
		l2.setBounds(150,5,400,80);
		l2.setFont(new Font("Osward",Font.BOLD,30));
		l2.setForeground(Color.GREEN);
		li.add(l2);
		
		// Label for Page3: Account Details
		l3=new JLabel("Page3: Account Details");
		l3.setBounds(200,45,400,80);
		l3.setFont(new Font("Osward",Font.BOLD,25));
		l3.setForeground(Color.GREEN);
		li.add(l3);
		
		// Font for all labels
		Font f1=new Font("Arial",Font.BOLD,25);
		
		// Font for all RadioButtons
		Font f2=new Font("Arial",Font.PLAIN,15);
		
		// Label for Account Type:
		l4=new JLabel("Account Type:");
		l4.setBounds(50,130,200,40);
		l4.setFont(f1);
		l4.setForeground(Color.CYAN);
		li.add(l4);
		
		// JRadioButton for Saving Account
		rb1=new JRadioButton("Saving Account");
		rb1.setBounds(50,180,150,25);
		rb1.setFont(f2);
		rb1.setSelected(true);
		li.add(rb1);
		
		// JRadioButton for Current Account
		rb2=new JRadioButton("Current Account");
		rb2.setBounds(300,180,150,25);
		rb2.setFont(f2);
		li.add(rb2);
		
		// JRadioButton for FD Account
		rb3=new JRadioButton("FD Account");
		rb3.setBounds(50,230,150,25);
		rb3.setFont(f2);
		li.add(rb3);
		
		// JRadioButton for Salary Account
		rb4=new JRadioButton("Salary Account");
		rb4.setBounds(300,230,150,25);
		rb4.setFont(f2);
		li.add(rb4);
		
		// ButtonGroup
		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		bg.add(rb4);
		
		// Label for Card Number:
		l5=new JLabel("Card Number:");
		l5.setBounds(50,290,200,40);
		l5.setFont(f1);
		l5.setForeground(Color.CYAN);
		li.add(l5);
		
		// Random card number
		Random rnd=new Random();
		rndno=rnd.nextInt(899999)+100000;
		crdno="4591150428"+rndno;
		// Random pin number
		pinno=rnd.nextInt(8999)+1000;
		
		// Label for XXXX-XXXX-XXXX-1234
		l6=new JLabel("XXXX-XXXX-XXXX-1234");
		l6.setBounds(250,290,280,40);
		l6.setFont(new Font("Arial",Font.PLAIN,20));
		l6.setForeground(Color.WHITE);
		li.add(l6);
		
		// Label for (This will appear on your ATM)
		l7=new JLabel("(This will appear on your ATM Card)");
		l7.setBounds(243,315,280,40);
		l7.setFont(new Font("Arial",Font.PLAIN,15));
		l7.setForeground(Color.GRAY);
		li.add(l7);
		
		// Label for PIN
		l8=new JLabel("PIN");
		l8.setBounds(50,360,150,40);
		l8.setFont(f1);
		l8.setForeground(Color.CYAN);
		li.add(l8);
		
		// Label for (4-digit Pswd):
		l9=new JLabel("(4-digit Pswd):");
		l9.setBounds(95,360,150,40);
		l9.setFont(new Font("Arial",Font.PLAIN,18));
		l9.setForeground(Color.WHITE);
		li.add(l9);
		
		// Label for XXXX
		l10=new JLabel("XXXX");
		l10.setBounds(250,360,100,40);
		l10.setFont(new Font("Arial",Font.PLAIN,20));
		l10.setForeground(Color.WHITE);
		li.add(l10);
		
		// Label for Services Required:
		l11=new JLabel("Services Required:");
		l11.setBounds(50,420,250,40);
		l11.setFont(f1);
		l11.setForeground(Color.CYAN);
		li.add(l11);
		
		// JCheckBox for ATM Card
		cb1=new JCheckBox("ATM Card");
		cb1.setBounds(50,470,150,25);
		cb1.setFont(f2);
		cb1.setSelected(true);
		li.add(cb1);
		
		// JCheckBox for Cheque Book
		cb2=new JCheckBox("Cheque Book");
		cb2.setBounds(300,470,150,25);
		cb2.setFont(f2);
		li.add(cb2);
		
		// JCheckBox for SMS Alert
		cb3=new JCheckBox("SMS Alert");
		cb3.setBounds(50,520,150,25);
		cb3.setFont(f2);
		li.add(cb3);
		
		// JCheckBox for Mobile Banking
		cb4=new JCheckBox("Mobile Banking");
		cb4.setBounds(300,520,150,25);
		cb4.setFont(f2);
		li.add(cb4);
		
		// JCheckBox for Declaration
		cb5=new JCheckBox("I declares that the above entered details are correct to the best of my knowledge");
		cb5.setBounds(25,580,570,25);
		cb5.setFont(new Font("Arial",Font.PLAIN,15));
		li.add(cb5);
		
		// Button for Submit
		b1=new JButton("Submit");
		b1.setBounds(430,640,120,40);
		b1.setFont(new Font("Serif",Font.PLAIN,25));
		b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.BLUE);
		b1.addActionListener(this);
		li.add(b1);
		
		if(!cb1.isSelected())
		{
			b1.setEnabled(false);
		}
		
		setBounds(300,50,650,750);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String AccType=null;
		if(rb1.isSelected())
		{
			AccType="Saving Account";
		}
		else if(rb2.isSelected())
		{
			AccType="Current Account";
		}
		else if(rb3.isSelected())
		{
			AccType="FD Account";
		}
		else if(rb4.isSelected())
		{
			AccType="Salary Account";
		}
		String Services="";
		if(cb1.isSelected())
		{
			Services=Services + "ATM_Card";
		}
		if(cb2.isSelected())
		{
			Services=Services + ", Cheque_Book";
		}
		if(cb3.isSelected())
		{
			Services=Services + ", SMS_Alert";
		}
		if(cb4.isSelected())
		{
			Services=Services + ", Mobile_Banking";
		}
		String sqlquery1="insert into signup3 values("+formno+",'"+AccType+"','"+Services+"','"+crdno+"','"+pinno+"')";
		String sqlquery2="insert into login values("+formno+",'"+crdno+"','"+pinno+"')";
		try
		{
			Class.forName(clsname);
			con=DriverManager.getConnection(url,usr,pswd);
			st=con.createStatement();
			st.executeUpdate(sqlquery1);
			st.executeUpdate(sqlquery2);
			
			JOptionPane.showMessageDialog(null,"Your Card_Number is: " +crdno+ "\n Your Pin_Number is: " +pinno+ "\n Please note your Card_No and Pin_No for future Login");
			setVisible(false);
			new Welcome().setVisible(true);
		}
		catch(Exception e)
		{ 
			System.out.println(e);
		}
	}
}