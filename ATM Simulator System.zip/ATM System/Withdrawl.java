import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Withdrawl extends JFrame implements ActionListener
{
	String crdno;
	Transaction tr1;
	JLabel li,l1;
	JTextField t1;
	JButton b1,b2,b3;
	
	Connection con;
	Statement st;
	ResultSet rs;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	public Withdrawl(String crdno,Transaction tr2)
	{
		this.crdno=crdno;
		tr1=tr2;
		
		// Background Image
		ImageIcon ic=new ImageIcon("atm.jpg");
		Image ii=ic.getImage().getScaledInstance(900,860,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,900,800);
		setUndecorated(true);
		add(li);
		
		// Label for Please Enter the Amount You Want to Withdrawl
		l1=new JLabel("Please Enter the Amount You Want to Withdrawl");
		l1.setBounds(160,250,500,40);
		l1.setForeground(Color.WHITE);
		l1.setFont(new Font("Osward",Font.BOLD,15));
		li.add(l1);
		
		// TextField for Amount
		t1=new JTextField();
		t1.setBounds(275,310,100,30);
		t1.setBackground(Color.BLACK);
		t1.setForeground(Color.WHITE);
		t1.setFont(new Font("Osward",Font.BOLD,17));
		t1.setBorder(null);
		li.add(t1);
		
		// Font for Buttons
		Font f1=new Font("Arial",Font.BOLD,16);
		
		// Cursor for Buttons
		Cursor cr=new Cursor(Cursor.HAND_CURSOR);
		
		// Button for Back
		b1=new JButton("Back");
		b1.setBounds(156,370,130,25);
		b1.setFont(f1);
		b1.setCursor(cr);
		b1.addActionListener(this);
		li.add(b1);
		
		// Button for Withdrawl
		b2=new JButton("Withdrawl");
		b2.setBounds(355,370,160,25);
		b2.setFont(f1);
		b2.setCursor(cr);
		b2.addActionListener(this);
		li.add(b2);
		
		// Button for EXIT
		b3=new JButton("EXIT");
		b3.setBounds(355,434,160,25);
		b3.setFont(f1);
		b3.setCursor(cr);
		b3.addActionListener(this);
		li.add(b3);
		
		
		setBounds(300,20,900,770);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			setVisible(false);
			tr1.setVisible(true);
		}
		if(ae.getSource()==b2)
		{
			String amount=t1.getText();
			if(amount.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Please Enter the Amount for Withdrawl");
			}
			else
			{
				try
				{
					Class.forName(clsname);
					con=DriverManager.getConnection(url,usr,pswd);
					st=con.createStatement();
					
					String query="select * from bank where card_no='"+crdno+"'";
					rs=st.executeQuery(query);
					int balance=0;
					while(rs.next())
					{
						if(rs.getString("transaction_type").equals("Deposit"))
						{
							balance = balance + Integer.parseInt(rs.getString("amount"));
						}
						else
						{
							balance = balance - Integer.parseInt(rs.getString("amount"));
						}
					}
					if(balance < Integer.parseInt(amount))
					{
						JOptionPane.showMessageDialog(null,"Insufficient Balance");
						return;
					}
					java.util.Date dt=new java.util.Date();
					String trtype="Withdrawl";
					String sqlquery="insert into bank values('"+crdno+"','"+dt+"','"+trtype+"','"+amount+"')";
					st.executeUpdate(sqlquery);
					JOptionPane.showMessageDialog(null,"RS "+amount+" Withdrawl Successfully");
					t1.setText("");
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
		if(ae.getSource()==b3)
		{
			System.exit(0);
		}
	}
}