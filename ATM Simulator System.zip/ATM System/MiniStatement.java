import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class MiniStatement extends JFrame
{
	String crdno;
	Transaction tr1;
	JLabel l1,l2,l3,l4;
	JButton b1,b2,b3,b4,b5;
	
	Connection con;
	Statement st;
	ResultSet rs;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	public MiniStatement(String crdno, Transaction tr2)
	{
		this.crdno=crdno;
		tr1=tr2;
		setTitle("Mini Statement");
		
		// Label for KAMCA Bank
		l1=new JLabel("KAMCA Bank");
		l1.setBounds(140,10,200,40);
		l1.setFont(new Font("System",Font.BOLD,30));
		add(l1);
		
		// Label for Card No:
		l2=new JLabel();
		l2.setBounds(10,90,300,30);
		l2.setFont(new Font("Osward",Font.BOLD,20));
		add(l2);
		
		// Label for MiniStatement
		l3=new JLabel();
		l3.setBounds(10,160,500,180);
		l3.setFont(new Font("Osward",Font.PLAIN,18));
		add(l3);
		
		// Label for Balance
		l4=new JLabel();
		l4.setBounds(10,380,350,20);
		l4.setFont(new Font("Osward",Font.BOLD,18));
		l4.setForeground(Color.BLUE);
		add(l4);
		
		l2.setText("Card No: "+crdno.substring(0,4)+"XXXXXXXX"+crdno.substring(12));
		
		String sqlquery="select * from bank where card_no='"+crdno+"'";
		int balance=0;
		try
		{
			Class.forName(clsname);
			con=DriverManager.getConnection(url,usr,pswd);
			st=con.createStatement();
			rs=st.executeQuery(sqlquery);
			while(rs.next())
			{
				l3.setText(l3.getText() + "<html>" + rs.getString("Transaction_date") + "&nbsp;&nbsp;&nbsp;" + rs.getString("Transaction_type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("amount") + "<br><br><html>");
				if(rs.getString("transaction_type").equals("Deposit"))
				{
					balance = balance + Integer.parseInt(rs.getString("amount"));
				}
				else
				{
					balance = balance - Integer.parseInt(rs.getString("amount"));
				}
			}
			l4.setText("Your Remaining Balance is: Rs "+balance);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
		setBounds(200,100,510,480);
		setLayout(null);
		setResizable(false);
		setVisible(true);
	}
}