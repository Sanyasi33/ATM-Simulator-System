import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Welcome extends JFrame implements ActionListener
{
	JLabel li,l1,l2,l3,l4,l5;
	JTextField t1;
	JPasswordField p1;
	JButton b1,b2,b3;
	
	Connection con;
	Statement st;
	ResultSet rs;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	public Welcome()
	{	
		setTitle("ATM SIMULATOR SYSTEM");
		
		// Background Image
		ImageIcon ic=new ImageIcon("bg1.jpg");
		Image ii=ic.getImage().getScaledInstance(700,500,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,700,500);
		add(li);
		
		// Label for Bank_logo
		ImageIcon ic1=new ImageIcon("logo.jpg");
		Image i=ic1.getImage().getScaledInstance(80,80,Image.SCALE_DEFAULT);
		ImageIcon ic2=new ImageIcon(i);
		l1=new JLabel(ic2);
		l1.setBounds(50,15,80,80);
		li.add(l1);
		
		// Label for Welcome_to_ATM
		l2=new JLabel("Welcome to ATM");
		l2.setBounds(160,7,500,100);
		l2.setFont(new Font("Osward",Font.BOLD,40));
		l2.setForeground(Color.GREEN);
		li.add(l2);
		
		// Font for card no and pin
		Font f1=new Font("Arial",Font.PLAIN,25);
		
		// Label for Card_no
		l3=new JLabel("Card No:");
		l3.setFont(f1);
		l3.setBounds(60,140,100,30);
		l3.setForeground(Color.CYAN);
		li.add(l3);
		
		// TextField for card no
		t1=new JTextField();
		t1.setBounds(180,140,250,35);
		t1.setFont(new Font("Arial",Font.PLAIN,25));
		li.add(t1);
		
		// Label for pin
		l4=new JLabel("Pin:");
		l4.setFont(f1);
		l4.setBounds(60,200,100,30);
		l4.setForeground(Color.CYAN);
		li.add(l4);
		
		// Label for New User please SignUp
		l5=new JLabel("New User please SignUp !!!");
		l5.setFont(new Font("Arial",Font.ITALIC,18));
		l5.setBounds(180,340,300,35);
		l5.setForeground(Color.ORANGE);
		li.add(l5);
		
		// PasswordField for pin
		p1=new JPasswordField();
		p1.setBounds(180,200,250,35);
		p1.setFont(new Font("Arial",Font.PLAIN,25));
		li.add(p1);
		
		// Font for buttons
		Font f2=new Font("Serif",Font.PLAIN,22);
		
		// Cursor for buttons
		Cursor cr=new Cursor(Cursor.HAND_CURSOR);
		
		// SignIn button
		b1=new JButton("SignIn");
		b1.setCursor(cr);
		b1.setFont(f2);
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.BLUE);
		b1.setBounds(180,300,100,35);
		li.add(b1);
		
		// Clear button
		b2=new JButton("Clear");
		b2.setCursor(cr);
		b2.setFont(f2);
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.WHITE);
		b2.setBounds(310,300,100,35);
		li.add(b2);
		
		// SignUp button
		b3=new JButton("SignUp");
		b3.setCursor(cr);
		b3.setFont(new Font("Serif",Font.ITALIC,22));
		b3.setBackground(Color.BLACK);
		b3.setForeground(Color.BLUE);
		b3.setBounds(180,380,230,35);
		li.add(b3);
		
		setBounds(300,50,650,500);
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		// Action Listener
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			String crdno=t1.getText();
			String pinno=p1.getText();
			
			String sqlquery="select * from login where card_no='"+crdno+"' and pin_no='"+pinno+"'";
			try
			{
				if(crdno.equals(""))
				{
					JOptionPane.showMessageDialog(null,"Card Number is Required");
				}
				else if(pinno.equals(""))
				{
					JOptionPane.showMessageDialog(null,"Pin Number is Required");
				}
				else
				{
					Class.forName(clsname);
					con=DriverManager.getConnection(url,usr,pswd);
					st=con.createStatement();
					rs=st.executeQuery(sqlquery);
					if(rs.next())
					{
						setVisible(false);
						Transaction t=new Transaction(crdno,this);
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Invalid Card_Number or Pin_Number");
					}
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		if(ae.getSource()==b2)
		{
			t1.setText("");
			p1.setText("");
		}
		if(ae.getSource()==b3)
		{
			setVisible(false);
			SignUp1 s1=new SignUp1(this);
		}
	}
	public static void main(String...args)
	{
		Welcome wc=new Welcome();
	}
}