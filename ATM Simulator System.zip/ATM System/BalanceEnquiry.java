import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class BalanceEnquiry extends JFrame implements ActionListener
{
	String crdno;
	Transaction tr1;
	JLabel li,l1;
	JButton b1,b2;
	
	int balance=0;
	
	Connection con;
	Statement st;
	ResultSet rs;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	public BalanceEnquiry(String crdno,Transaction tr2)
	{
		this.crdno=crdno;
		tr1=tr2;
		
		// Background Image
		ImageIcon ic=new ImageIcon("atm.jpg");
		Image i1=ic.getImage().getScaledInstance(900,860,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(i1);
		li=new JLabel(icc);
		li.setBounds(0,0,900,800);
		setUndecorated(true);
		add(li);
		
		try
		{
			Class.forName(clsname);
			con=DriverManager.getConnection(url,usr,pswd);
			st=con.createStatement();
				
			String query="select * from bank where card_no='"+crdno+"'";
			rs=st.executeQuery(query);
			while(rs.next())
			{
				if(rs.getString("transaction_type").equals("Deposit"))
				{
					balance = balance + Integer.parseInt(rs.getString("amount"));
				}
				else
				{
					balance = balance - Integer.parseInt(rs.getString("amount"));
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		l1=new JLabel("Your Account Balance is: RS  "+balance);
		l1.setBounds(180,250,500,40);
		l1.setFont(new Font("Osward",Font.BOLD,18));
		l1.setForeground(Color.WHITE);
		li.add(l1);
		
		// Font for Buttons
		Font f1=new Font("Arial",Font.BOLD,16);
		
		// Cursor for Buttons
		Cursor cr=new Cursor(Cursor.HAND_CURSOR);
		
		// Button for Back
		b1=new JButton("Back");
		b1.setBounds(156,467,130,25);
		b1.setFont(f1);
		b1.setCursor(cr);
		b1.addActionListener(this);
		li.add(b1);
		
		// Button for EXIT
		b2=new JButton("EXIT");
		b2.setBounds(355,467,160,25);
		b2.setFont(f1);
		b2.setCursor(cr);
		b2.addActionListener(this);
		li.add(b2);
		
		setBounds(300,20,900,770);
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			setVisible(false);
			tr1.setVisible(true);
		}
		if(ae.getSource()==b2)
		{
			System.exit(0);
		}
	}
}