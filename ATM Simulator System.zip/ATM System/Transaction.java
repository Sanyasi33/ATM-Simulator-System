import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Transaction extends JFrame implements ActionListener
{
	String crdno;
	Welcome wcc1;
	JLabel li,l1;
	JButton b1,b2,b3,b4,b5,b6,b7;
	
	public Transaction(String crdno,Welcome wcc2)
	{
		this.crdno=crdno;
		wcc1=wcc2;
		
		// Background Image
		ImageIcon ic=new ImageIcon("atm.jpg");
		Image ii=ic.getImage().getScaledInstance(900,860,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,900,800);
		setUndecorated(true);
		add(li);
		
		// Label for Please Select Your Transaction
		l1=new JLabel("Please Select Your Transaction");
		l1.setBounds(185,250,500,40);
		l1.setForeground(Color.WHITE);
		l1.setFont(new Font("Osward",Font.BOLD,20));
		li.add(l1);
		
		// Font for Buttons
		Font f1=new Font("Arial",Font.BOLD,16);
		
		// Cursor for Buttons
		Cursor cr=new Cursor(Cursor.HAND_CURSOR);
		
		// Button for Deposit
		b1=new JButton("Deposit");
		b1.setBounds(156,370,130,25);
		b1.setFont(f1);
		b1.setCursor(cr);
		b1.addActionListener(this);
		li.add(b1);
		
		// Button for Withdrawl
		b2=new JButton("Withdrawl");
		b2.setBounds(355,370,160,25);
		b2.setFont(f1);
		b2.setCursor(cr);
		b2.addActionListener(this);
		li.add(b2);
		
		// Button for Fast Cash
		b3=new JButton("Fast Cash");
		b3.setBounds(156,402,130,25);
		b3.setFont(f1);
		b3.setCursor(cr);
		b3.addActionListener(this);
		li.add(b3);
		
		// Button for Balance Enquiry
		b4=new JButton("Balance Enquiry");
		b4.setBounds(355,402,160,25);
		b4.setFont(f1);
		b4.setCursor(cr);
		b4.addActionListener(this);
		li.add(b4);
		
		// Button for Pin Change
		b5=new JButton("Pin Change");
		b5.setBounds(156,434,130,25);
		b5.setFont(f1);
		b5.setCursor(cr);
		b5.addActionListener(this);
		li.add(b5);
		
		// Button for Mini Statement
		b6=new JButton("Mini Statement");
		b6.setBounds(355,434,160,25);
		b6.setFont(f1);
		b6.setCursor(cr);
		b6.addActionListener(this);
		li.add(b6);
		
		// Button for EXIT
		b7=new JButton("EXIT");
		b7.setBounds(355,466,160,25);
		b7.setFont(f1);
		b7.setCursor(cr);
		b7.addActionListener(this);
		li.add(b7);
		
		setBounds(300,20,900,770);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			setVisible(false);
			Deposit d1=new Deposit(crdno,this);
		}
		if(ae.getSource()==b2)
		{
			setVisible(false);
			Withdrawl wd=new Withdrawl(crdno,this);
		}
		if(ae.getSource()==b3)
		{
			setVisible(false);
			FastCash fc=new FastCash(crdno,this);
		}
		if(ae.getSource()==b4)
		{
			setVisible(false);
			BalanceEnquiry be=new BalanceEnquiry(crdno,this);
		}
		if(ae.getSource()==b5)
		{
			setVisible(false);
			PinChange pc=new PinChange(crdno,this);
		}
		if(ae.getSource()==b6)
		{
			MiniStatement ms=new MiniStatement(crdno,this);
		}
		if(ae.getSource()==b7)
		{
			System.exit(0);
		}
	}
}