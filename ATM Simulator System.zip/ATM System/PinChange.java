import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;
import java.sql.*;
public class PinChange extends JFrame implements ActionListener
{
	String crdno;
	Transaction tr1;
	JLabel li,l1,l2;
	JPasswordField p1,p2;
	JButton b1,b2,b3;
	
	Connection con;
	Statement st;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	// 4-digit Pin Validation
	String panRegex="[0-9]{4}";
	Pattern ptrn=Pattern.compile(panRegex);
	
	public PinChange(String crdno,Transaction tr2)
	{
		this.crdno=crdno;
		tr1=tr2;
		
		// Background Image
		ImageIcon ic=new ImageIcon("atm.jpg");
		Image i1=ic.getImage().getScaledInstance(900,860,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(i1);
		li=new JLabel(icc);
		li.setBounds(0,0,900,800);
		setUndecorated(true);
		add(li);
		
		// Label for Enter New Pin
		l1=new JLabel("Enter New Pin:");
		l1.setBounds(160,265,150,40);
		l1.setForeground(Color.WHITE);
		l1.setFont(new Font("Osward",Font.BOLD,17));
		li.add(l1);
		
		// PasswordField for Enter New Pin
		p1=new JPasswordField();
		p1.setBounds(350,270,150,30);
		p1.setFont(new Font("System",Font.BOLD,25));
		li.add(p1);
		
		// Label for Re-Enter New Pin
		l2=new JLabel("Re-Enter New Pin:");
		l2.setBounds(160,305,150,40);
		l2.setForeground(Color.WHITE);
		l2.setFont(new Font("Osward",Font.BOLD,17));
		li.add(l2);
		
		// PasswordField for Re-Enter New Pin
		p2=new JPasswordField();
		p2.setBounds(350,310,150,30);
		p2.setFont(new Font("System",Font.BOLD,25));
		li.add(p2);
		
		// Font for Buttons
		Font f1=new Font("Arial",Font.BOLD,16);
		
		// Cursor for Buttons
		Cursor cr=new Cursor(Cursor.HAND_CURSOR);
		
		// Button for Change
		b1=new JButton("Change");
		b1.setBounds(355,434,160,25);
		b1.setFont(f1);
		b1.setCursor(cr);
		b1.addActionListener(this);
		li.add(b1);
		
		// Button for Back
		b2=new JButton("Back");
		b2.setBounds(156,466,130,25);
		b2.setFont(f1);
		b2.setCursor(cr);
		b2.addActionListener(this);
		li.add(b2);
		
		// Button for EXIT
		b3=new JButton("EXIT");
		b3.setBounds(355,466,160,25);
		b3.setFont(f1);
		b3.setCursor(cr);
		b3.addActionListener(this);
		li.add(b3);
		
		setBounds(300,20,900,770);
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			String ep=p1.getText();
			String rep=p2.getText();
			if(!(ptrn.matcher(ep).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Only 4-digit Number");
			}
			else if(!(ptrn.matcher(rep).matches()))
			{
				JOptionPane.showMessageDialog(null,"Please Enter Only 4-digit Number");
			}
			else if(!ep.equals(rep))
			{
				JOptionPane.showMessageDialog(null,"Entered Pin does not Match");
			}
			else
			{
				String sqlquery1="update signup3 set pin_no='"+rep+"' where card_no='"+crdno+"'";
				String sqlquery2="update login set pin_no='"+rep+"' where card_no='"+crdno+"'";
				try
				{
					Class.forName(clsname);
					con=DriverManager.getConnection(url,usr,pswd);
					st=con.createStatement();
					st.executeUpdate(sqlquery1);
					st.executeUpdate(sqlquery2);
					JOptionPane.showMessageDialog(null,"Pin Changed Successfully");
					p1.setText("");
					p2.setText("");
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
		}
		if(ae.getSource()==b2)
		{
			setVisible(false);
			tr1.setVisible(true);
		}
		if(ae.getSource()==b3)
		{
			System.exit(0);
		}
	}
}