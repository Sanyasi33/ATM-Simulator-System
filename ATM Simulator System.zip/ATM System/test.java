import java.sql.*;
public class test
{
	Connection con;
	Statement st;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String usr="system";
	String pswd="sanny";
	
	public void m1() throws Exception
	{
		String sqlquery="insert into sample values(1,'sanny')";
		Class.forName(clsname);
		con=DriverManager.getConnection(url,usr,pswd);
		st=con.createStatement();
		st.executeUpdate(sqlquery);
		System.out.println("Data inserted successfully");
	}
	public static void main(String...args) throws Exception
	{
		test t=new test();
		t.m1();
	}
}