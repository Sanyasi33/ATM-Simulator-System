import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;
public class FastCash extends JFrame implements ActionListener
{
	String crdno;
	Transaction tr1;
	JLabel li,l1;
	JButton b1,b2,b3,b4,b5,b6,b7,b8;
	
	Connection con;
	Statement st;
	ResultSet rs;
	String clsname="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	// String usr="ams";
	// String pswd="sanyasi";
	String usr="system";
	String pswd="sanny";
	
	public FastCash(String crdno,Transaction tr2)
	{
		this.crdno=crdno;
		tr1=tr2;
		
		// Background Image
		ImageIcon ic=new ImageIcon("atm.jpg");
		Image ii=ic.getImage().getScaledInstance(900,860,Image.SCALE_DEFAULT);
		ImageIcon icc=new ImageIcon(ii);
		li=new JLabel(icc);
		li.setBounds(0,0,900,800);
		setUndecorated(true);
		add(li);
		
		// Label for Select Withdrawl Amount
		l1=new JLabel("Select Withdrawl Amount");
		l1.setBounds(220,250,500,40);
		l1.setForeground(Color.WHITE);
		l1.setFont(new Font("Osward",Font.BOLD,18));
		li.add(l1);
		
		// Font for Buttons
		Font f1=new Font("Arial",Font.BOLD,16);
		
		// Cursor for Buttons
		Cursor cr=new Cursor(Cursor.HAND_CURSOR);
		
		// Button for 500
		b1=new JButton("500");
		b1.setBounds(156,370,130,25);
		b1.setFont(f1);
		b1.setCursor(cr);
		b1.addActionListener(this);
		li.add(b1);
		
		// Button for 1000
		b2=new JButton("1000");
		b2.setBounds(355,370,160,25);
		b2.setFont(f1);
		b2.setCursor(cr);
		b2.addActionListener(this);
		li.add(b2);
		
		// Button for 2000
		b3=new JButton("2000");
		b3.setBounds(156,402,130,25);
		b3.setFont(f1);
		b3.setCursor(cr);
		b3.addActionListener(this);
		li.add(b3);
		
		// Button for 5000
		b4=new JButton("5000");
		b4.setBounds(355,402,160,25);
		b4.setFont(f1);
		b4.setCursor(cr);
		b4.addActionListener(this);
		li.add(b4);
		
		// Button for 10000
		b5=new JButton("10000");
		b5.setBounds(156,434,130,25);
		b5.setFont(f1);
		b5.setCursor(cr);
		b5.addActionListener(this);
		li.add(b5);
		
		// Button for 20000
		b6=new JButton("20000");
		b6.setBounds(355,434,160,25);
		b6.setFont(f1);
		b6.setCursor(cr);
		b6.addActionListener(this);
		li.add(b6);
		
		// Button for Back
		b7=new JButton("Back");
		b7.setBounds(156,466,130,25);
		b7.setFont(f1);
		b7.setCursor(cr);
		b7.addActionListener(this);
		li.add(b7);
		
		// Button for EXIT
		b8=new JButton("EXIT");
		b8.setBounds(355,466,160,25);
		b8.setFont(f1);
		b8.setCursor(cr);
		b8.addActionListener(this);
		li.add(b8);
		
		setBounds(300,20,900,770);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b7)
		{
			setVisible(false);
			tr1.setVisible(true);
		}
		else if(ae.getSource()==b8)
		{
			System.exit(0);
		}
		else
		{
			String amount=((JButton)ae.getSource()).getText();
			try
			{
				Class.forName(clsname);
				con=DriverManager.getConnection(url,usr,pswd);
				st=con.createStatement();
				
				String query="select * from bank where card_no='"+crdno+"'";
				rs=st.executeQuery(query);
				int balance=0;
				while(rs.next())
				{
					if(rs.getString("transaction_type").equals("Deposit"))
					{
						balance = balance + Integer.parseInt(rs.getString("amount"));
					}
					else
					{
						balance = balance - Integer.parseInt(rs.getString("amount"));
					}
				}
				if(((ae.getSource()!=b7) && (ae.getSource()!=b8)) && (balance < Integer.parseInt(amount)))
				{
					JOptionPane.showMessageDialog(null,"Insufficient Balance");
					return;
				}
				Date dt=new Date();
				String trtype="Withdrawl";
				String sqlquery="insert into bank values('"+crdno+"','"+dt+"','"+trtype+"','"+amount+"')";
				st.executeUpdate(sqlquery);
				JOptionPane.showMessageDialog(null,"RS "+amount+" Debited Successfully");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
}